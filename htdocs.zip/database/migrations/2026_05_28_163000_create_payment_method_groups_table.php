<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_method_groups', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->json('methods')->nullable(); // Array of payment_method IDs
            $table->integer('position')->default(0);
            $table->boolean('status')->default(true);
            $table->string('domain')->nullable();
            $table->timestamps();

            $table->index('domain');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_method_groups');
    }
};
